#ifndef   __USB_IRQ_H__
#define   __USB_IRQ_H__

//  IRQ basic action for usb
void disable(void);
void enable(void);

#endif
